javascript

function clearDisplay() {

    document.getElementById('display').value = '';

}

function appendToDisplay(value) {

    document.getElementById('display').value += value;

}

function solveEquation() {

    try {

        const result = eval(document.getElementById('display').value);

        document.getElementById('display').value = result;

    } catch (error) {

        document.getElementById('display').value = 'Error';

    }

}

function solveQuadratic() {

    const a = parseFloat(prompt("Enter coefficient a:"));

    const b = parseFloat(prompt("Enter coefficient b:"));

    const c = parseFloat(prompt("Enter coefficient c:"));

    const discriminant = b * b - 4 * a * c;

    let solutions;

    if (discriminant > 0) {

        const x1 = (-b + Math.sqrt(discriminant)) / (2 * a);

        const x2 = (-b - Math.sqrt(discriminant)) / (2 * a);

        solutions = `x1 = ${x1}, x2 = ${x2}`;

    } else if (discriminant === 0) {

        const x = -b / (2 * a);

        solutions = `x = ${x}`;

    } else {

        solutions = "No real solutions";

    }

    document.getElementById('display').value = solutions;

}